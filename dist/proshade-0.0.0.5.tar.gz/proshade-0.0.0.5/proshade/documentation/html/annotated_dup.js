var annotated_dup =
[
    [ "ProSHADE_internal_data", "namespace_pro_s_h_a_d_e__internal__data.html", "namespace_pro_s_h_a_d_e__internal__data" ],
    [ "ProSHADE_internal_maths", "namespace_pro_s_h_a_d_e__internal__maths.html", "namespace_pro_s_h_a_d_e__internal__maths" ],
    [ "ProSHADE_internal_spheres", "namespace_pro_s_h_a_d_e__internal__spheres.html", "namespace_pro_s_h_a_d_e__internal__spheres" ],
    [ "ProSHADE_exception", "class_pro_s_h_a_d_e__exception.html", "class_pro_s_h_a_d_e__exception" ],
    [ "ProSHADE_internal_maths_bicubicInterpolator", "class_pro_s_h_a_d_e__internal__maths__bicubic_interpolator.html", null ],
    [ "ProSHADE_run", "class_pro_s_h_a_d_e__run.html", "class_pro_s_h_a_d_e__run" ],
    [ "ProSHADE_settings", "class_pro_s_h_a_d_e__settings.html", "class_pro_s_h_a_d_e__settings" ]
];