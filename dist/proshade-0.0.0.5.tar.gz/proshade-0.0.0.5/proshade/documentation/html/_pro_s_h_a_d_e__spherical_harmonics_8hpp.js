var _pro_s_h_a_d_e__spherical_harmonics_8hpp =
[
    [ "allocateComputationMemory", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#aefc1302e14aeda70290390bda39da952", null ],
    [ "applyCondonShortleyPhase", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#aa25c84ea82e4faeb0f41f738a56ca28d", null ],
    [ "computeSphericalHarmonics", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#a3fa7caeb0d21183a39d7cca2d889c437", null ],
    [ "computeSphericalTransformCoeffs", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#aac193f1c8e516f31d272b4ba5ea21b26", null ],
    [ "initialiseAllMemory", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#aa3e5098a48755bb2665044472d619029", null ],
    [ "initialiseFFTWPlans", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#a38c2dcddc09fd31877eecb17f1d84aa7", null ],
    [ "initialSplitDiscreteTransform", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#a0d0b0cf8683acd16bc76285b3897b66f", null ],
    [ "placeWithinWorkspacePointers", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#a86bb427280a75c3422b7a7781253be50", null ],
    [ "releaseSphericalMemory", "_pro_s_h_a_d_e__spherical_harmonics_8hpp.html#a18ff35433a5459c948344bae4bf6284c", null ]
];