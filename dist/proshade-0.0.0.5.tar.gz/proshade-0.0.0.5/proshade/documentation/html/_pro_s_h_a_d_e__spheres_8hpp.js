var _pro_s_h_a_d_e__spheres_8hpp =
[
    [ "ProSHADE_sphere", "class_pro_s_h_a_d_e__internal__spheres_1_1_pro_s_h_a_d_e__sphere.html", "class_pro_s_h_a_d_e__internal__spheres_1_1_pro_s_h_a_d_e__sphere" ],
    [ "ProSHADE_rotFun_spherePeakGroup", "class_pro_s_h_a_d_e__internal__spheres_1_1_pro_s_h_a_d_e__rot_fun__sphere_peak_group.html", "class_pro_s_h_a_d_e__internal__spheres_1_1_pro_s_h_a_d_e__rot_fun__sphere_peak_group" ],
    [ "autoDetermineBandwidth", "_pro_s_h_a_d_e__spheres_8hpp.html#a9592e9df40cf87ee1d1c43d6b3508e1c", null ],
    [ "autoDetermineIntegrationOrder", "_pro_s_h_a_d_e__spheres_8hpp.html#a612cf0a1e92ea1e5f0b9bdb820a4b60e", null ],
    [ "autoDetermineSphereDistances", "_pro_s_h_a_d_e__spheres_8hpp.html#a51e14f3a4ce99f8e39497bbce12e28c7", null ]
];