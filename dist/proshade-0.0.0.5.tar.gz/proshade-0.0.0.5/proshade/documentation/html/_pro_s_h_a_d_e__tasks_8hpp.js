var _pro_s_h_a_d_e__tasks_8hpp =
[
    [ "checkDistancesSettings", "_pro_s_h_a_d_e__tasks_8hpp.html#a381e43e3bc24c15d616841f68acae3d8", null ],
    [ "checkMapManipulationSettings", "_pro_s_h_a_d_e__tasks_8hpp.html#abc52bbea60912b7a4b915af1be7e2ea6", null ],
    [ "checkOverlaySettings", "_pro_s_h_a_d_e__tasks_8hpp.html#a5ae8688ab6c6e0e38daffd3a1236eb00", null ],
    [ "checkSymmetrySettings", "_pro_s_h_a_d_e__tasks_8hpp.html#ac9c124db0e64e1425f32bff7659423d1", null ],
    [ "DistancesComputationTask", "_pro_s_h_a_d_e__tasks_8hpp.html#a104ae331628baf5dc1cd2af78a509624", null ],
    [ "MapManipulationTask", "_pro_s_h_a_d_e__tasks_8hpp.html#a284518fd53c37bc487a3bd4dd3556f6d", null ],
    [ "MapOverlayTask", "_pro_s_h_a_d_e__tasks_8hpp.html#a114d8a63107c845fd8ec9d7ad3deba23", null ],
    [ "ReportDistancesResults", "_pro_s_h_a_d_e__tasks_8hpp.html#a748a3eb5fb62a7b0fa6dcd9898f51dc2", null ],
    [ "SymmetryDetectionTask", "_pro_s_h_a_d_e__tasks_8hpp.html#a55c118485519804fba19ab4e17147759", null ]
];