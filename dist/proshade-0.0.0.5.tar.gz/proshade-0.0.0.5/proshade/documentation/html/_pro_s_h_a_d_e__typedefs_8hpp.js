var _pro_s_h_a_d_e__typedefs_8hpp =
[
    [ "__PROSHADE_TYPEDEFS__", "_pro_s_h_a_d_e__typedefs_8hpp.html#ab396d87d5a276856609a4401e198e044", null ],
    [ "_USE_MATH_DEFINES", "_pro_s_h_a_d_e__typedefs_8hpp.html#a525335710b53cb064ca56b936120431e", null ],
    [ "proshade_complex", "_pro_s_h_a_d_e__typedefs_8hpp.html#a10134cf48549b890102ac9d6459f8218", null ],
    [ "proshade_double", "_pro_s_h_a_d_e__typedefs_8hpp.html#acfed351cfd7495b3548de559c62a4d9e", null ],
    [ "proshade_signed", "_pro_s_h_a_d_e__typedefs_8hpp.html#a7a2e924855f89dbdb3b14c35de0d5109", null ],
    [ "proshade_single", "_pro_s_h_a_d_e__typedefs_8hpp.html#acc627bc7141aed99b8ea6991271922e2", null ],
    [ "proshade_triplet", "_pro_s_h_a_d_e__typedefs_8hpp.html#aa96123a7a32fdd57502af86534300e95", null ],
    [ "proshade_unsign", "_pro_s_h_a_d_e__typedefs_8hpp.html#a0b5177c64e73d6fbfcf47312f4fc00f9", null ],
    [ "ProSHADE_Task", "_pro_s_h_a_d_e__typedefs_8hpp.html#a605d5ad2dfb1809d612579de57fc1319", [
      [ "NA", "_pro_s_h_a_d_e__typedefs_8hpp.html#a605d5ad2dfb1809d612579de57fc1319ac75245149c3f64d74430b8996b1e0558", null ],
      [ "Distances", "_pro_s_h_a_d_e__typedefs_8hpp.html#a605d5ad2dfb1809d612579de57fc1319acf0772d2de2271c6cfd7d543b68a5ca6", null ],
      [ "Symmetry", "_pro_s_h_a_d_e__typedefs_8hpp.html#a605d5ad2dfb1809d612579de57fc1319afe33853b7c13a8848f8e147514305e31", null ],
      [ "OverlayMap", "_pro_s_h_a_d_e__typedefs_8hpp.html#a605d5ad2dfb1809d612579de57fc1319a03de6d7397dcb4efd3dcbc0f3d74ed2d", null ],
      [ "MapManip", "_pro_s_h_a_d_e__typedefs_8hpp.html#a605d5ad2dfb1809d612579de57fc1319ae263b097dd6d84be049deee0a11f3285", null ]
    ] ]
];