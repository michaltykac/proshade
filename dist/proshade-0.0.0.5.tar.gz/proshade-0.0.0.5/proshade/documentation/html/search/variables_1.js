var searchData=
[
  ['bangle_1206',['bAngle',['../class_pro_s_h_a_d_e__internal__data_1_1_pro_s_h_a_d_e__data.html#a9dbcec9f32eb76625d7aa59d8c2701d9',1,'ProSHADE_internal_data::ProSHADE_data']]],
  ['blurfactor_1207',['blurFactor',['../class_pro_s_h_a_d_e__settings.html#a51c87d0b415c8eaa517dbb9b5496e7e9',1,'ProSHADE_settings']]],
  ['boundsextraspace_1208',['boundsExtraSpace',['../class_pro_s_h_a_d_e__settings.html#a633435d4c8a7fd6533016c00ad9ba791',1,'ProSHADE_settings']]],
  ['boundssimilaritythreshold_1209',['boundsSimilarityThreshold',['../class_pro_s_h_a_d_e__settings.html#a827e3241fa6401027e0526fffb8b281d',1,'ProSHADE_settings']]]
];
