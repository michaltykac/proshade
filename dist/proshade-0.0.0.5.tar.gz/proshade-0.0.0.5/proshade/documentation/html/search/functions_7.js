var searchData=
[
  ['initialiseallmemory_1010',['initialiseAllMemory',['../namespace_pro_s_h_a_d_e__internal__spherical_harmonics.html#aa3e5098a48755bb2665044472d619029',1,'ProSHADE_internal_sphericalHarmonics']]],
  ['initialisefftwplans_1011',['initialiseFFTWPlans',['../namespace_pro_s_h_a_d_e__internal__spherical_harmonics.html#a38c2dcddc09fd31877eecb17f1d84aa7',1,'ProSHADE_internal_sphericalHarmonics']]],
  ['initialiseinverseshcomputation_1012',['initialiseInverseSHComputation',['../namespace_pro_s_h_a_d_e__internal__overlay.html#ac173210899aeeae2e207f9acdd7670a7',1,'ProSHADE_internal_overlay']]],
  ['initialsplitdiscretetransform_1013',['initialSplitDiscreteTransform',['../namespace_pro_s_h_a_d_e__internal__spherical_harmonics.html#a0d0b0cf8683acd16bc76285b3897b66f',1,'ProSHADE_internal_sphericalHarmonics']]],
  ['interpolatealongfirst_1014',['interpolateAlongFirst',['../class_pro_s_h_a_d_e__internal__spheres_1_1_pro_s_h_a_d_e__sphere.html#a01767ce99492c8f3b5fb33f2945e629f',1,'ProSHADE_internal_spheres::ProSHADE_sphere']]],
  ['interpolatealongsecond_1015',['interpolateAlongSecond',['../class_pro_s_h_a_d_e__internal__spheres_1_1_pro_s_h_a_d_e__sphere.html#a47a2a0198036c23f6fa1b0c4c9d75d3a',1,'ProSHADE_internal_spheres::ProSHADE_sphere']]],
  ['interpolatemapfromspheres_1016',['interpolateMapFromSpheres',['../class_pro_s_h_a_d_e__internal__data_1_1_pro_s_h_a_d_e__data.html#a94e35e44abd71bec01e959cd0d106cfa',1,'ProSHADE_internal_data::ProSHADE_data']]],
  ['interpolatespherevalues_1017',['interpolateSphereValues',['../class_pro_s_h_a_d_e__internal__spheres_1_1_pro_s_h_a_d_e__rot_fun__sphere.html#af915e4a94ebca294b9adc39b1badca5e',1,'ProSHADE_internal_spheres::ProSHADE_rotFun_sphere']]],
  ['invertmirrormap_1018',['invertMirrorMap',['../class_pro_s_h_a_d_e__internal__data_1_1_pro_s_h_a_d_e__data.html#aa67115a6b234764c958899863fb60b54',1,'ProSHADE_internal_data::ProSHADE_data']]],
  ['invertshcoefficients_1019',['invertSHCoefficients',['../class_pro_s_h_a_d_e__internal__data_1_1_pro_s_h_a_d_e__data.html#ac3dbae1c18d0550ee1940cadb5335684',1,'ProSHADE_internal_data::ProSHADE_data']]],
  ['isaxisunique_1020',['isAxisUnique',['../namespace_pro_s_h_a_d_e__internal__maths.html#a2380a3710f7dbe672519c3adda30f7cd',1,'ProSHADE_internal_maths::isAxisUnique(std::vector&lt; proshade_double * &gt; *CSymList, proshade_double *axis, proshade_double tolerance=0.1, bool improve=false)'],['../namespace_pro_s_h_a_d_e__internal__maths.html#a49f093fbdd34498d27a4d8998b620c91',1,'ProSHADE_internal_maths::isAxisUnique(std::vector&lt; proshade_double * &gt; *CSymList, proshade_double X, proshade_double Y, proshade_double Z, proshade_double fold, proshade_double tolerance)']]],
  ['isbandwithinshell_1021',['isBandWithinShell',['../namespace_pro_s_h_a_d_e__internal__distances.html#a6e15740000a0079151a2d24dbbdebb2e',1,'ProSHADE_internal_distances']]],
  ['isfilemap_1022',['isFileMAP',['../namespace_pro_s_h_a_d_e__internal__io.html#ae496132c658b22a5abb5d7aaca5e1f56',1,'ProSHADE_internal_io']]],
  ['isfilepdb_1023',['isFilePDB',['../namespace_pro_s_h_a_d_e__internal__io.html#abc5e6a82b6b44e3666abfc190dc0bc64',1,'ProSHADE_internal_io']]],
  ['issymmetrysame_1024',['isSymmetrySame',['../namespace_pro_s_h_a_d_e__internal__symmetry.html#abb4d85e82d1c55d0aa18795fea449adf',1,'ProSHADE_internal_symmetry']]]
];
