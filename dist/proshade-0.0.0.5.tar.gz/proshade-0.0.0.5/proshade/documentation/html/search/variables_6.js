var searchData=
[
  ['halfmapkernel_1225',['halfMapKernel',['../class_pro_s_h_a_d_e__settings.html#a8d2299cb1a7b0470e0f26e431af2548f',1,'ProSHADE_settings']]]
];
