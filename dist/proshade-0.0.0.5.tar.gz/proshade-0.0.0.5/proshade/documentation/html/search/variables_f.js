var searchData=
[
  ['usebicubicinterpolationonpeaks_1288',['useBiCubicInterpolationOnPeaks',['../class_pro_s_h_a_d_e__settings.html#afb183823a47a73d459a5bae16042bf4e',1,'ProSHADE_settings']]],
  ['usecorrelationmasking_1289',['useCorrelationMasking',['../class_pro_s_h_a_d_e__settings.html#a9f2447c98c5d2f2aa0768f7599f8954f',1,'ProSHADE_settings']]],
  ['usepeaksearchinrotationfunctionspace_1290',['usePeakSearchInRotationFunctionSpace',['../class_pro_s_h_a_d_e__settings.html#ab8d152f5e2e5dc0a64048d2e9c0d8d12',1,'ProSHADE_settings']]],
  ['usephase_1291',['usePhase',['../class_pro_s_h_a_d_e__settings.html#a2019a6bae1b3e6f7d8805ae2734b769e',1,'ProSHADE_settings']]],
  ['usesamebounds_1292',['useSameBounds',['../class_pro_s_h_a_d_e__settings.html#a1f0d2cb45fee521ddb2d0bc30beff3ec',1,'ProSHADE_settings']]]
];
