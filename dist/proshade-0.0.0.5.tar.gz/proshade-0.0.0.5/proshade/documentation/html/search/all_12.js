var searchData=
[
  ['vectormeanandsd_606',['vectorMeanAndSD',['../namespace_pro_s_h_a_d_e__internal__maths.html#a8a7c6330e101fb6d729aaf6f545db9c8',1,'ProSHADE_internal_maths']]],
  ['vectormedianandiqr_607',['vectorMedianAndIQR',['../namespace_pro_s_h_a_d_e__internal__maths.html#af185ca14eb5d82fb126092767746e00a',1,'ProSHADE_internal_maths']]],
  ['vectororientationsimilarity_608',['vectorOrientationSimilarity',['../namespace_pro_s_h_a_d_e__internal__maths.html#a2b2f67cba1eea57f19fdaf062db74fde',1,'ProSHADE_internal_maths']]],
  ['vectororientationsimilaritysamedirection_609',['vectorOrientationSimilaritySameDirection',['../namespace_pro_s_h_a_d_e__internal__maths.html#a79e789452e327bb07a53c5358f4d3eb0',1,'ProSHADE_internal_maths']]],
  ['verbose_610',['verbose',['../class_pro_s_h_a_d_e__settings.html#a89094c73ae033812d4df0bd846e03442',1,'ProSHADE_settings']]]
];
