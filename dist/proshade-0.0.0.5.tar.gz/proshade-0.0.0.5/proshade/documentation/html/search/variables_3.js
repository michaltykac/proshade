var searchData=
[
  ['detectedsymmetry_1217',['detectedSymmetry',['../class_pro_s_h_a_d_e__settings.html#a42b012ec753ebd1d87a0b6f557e97d1a',1,'ProSHADE_settings']]]
];
