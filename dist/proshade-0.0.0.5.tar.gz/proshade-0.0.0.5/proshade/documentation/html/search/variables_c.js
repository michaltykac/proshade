var searchData=
[
  ['reboxmap_1266',['reBoxMap',['../class_pro_s_h_a_d_e__settings.html#a90f225894304c4894f6106498e1d7729',1,'ProSHADE_settings']]],
  ['recommendedsymmetryfold_1267',['recommendedSymmetryFold',['../class_pro_s_h_a_d_e__settings.html#ac8e62cc8dbd40265e51143c8207b6638',1,'ProSHADE_settings']]],
  ['recommendedsymmetrytype_1268',['recommendedSymmetryType',['../class_pro_s_h_a_d_e__settings.html#ac39560ba9aca9053753c158fb2adb9de',1,'ProSHADE_settings']]],
  ['removewaters_1269',['removeWaters',['../class_pro_s_h_a_d_e__settings.html#acea4abeec3e2b45524e23809a69dce9d',1,'ProSHADE_settings']]],
  ['requestedresolution_1270',['requestedResolution',['../class_pro_s_h_a_d_e__settings.html#a7d0a63b2ac89e4f0df85ce5053c6bd87',1,'ProSHADE_settings']]],
  ['requestedsymmetryfold_1271',['requestedSymmetryFold',['../class_pro_s_h_a_d_e__settings.html#a6dc170d9826bad9ce4a2c31a033f7f6a',1,'ProSHADE_settings']]],
  ['requestedsymmetrytype_1272',['requestedSymmetryType',['../class_pro_s_h_a_d_e__settings.html#ab59297b3604ced939e30eaacd2eaaccb',1,'ProSHADE_settings']]],
  ['rotationuncertainty_1273',['rotationUncertainty',['../class_pro_s_h_a_d_e__settings.html#ad9c57832756d4ea342589104cdaded6b',1,'ProSHADE_settings']]],
  ['rotsphericalharmonics_1274',['rotSphericalHarmonics',['../class_pro_s_h_a_d_e__internal__data_1_1_pro_s_h_a_d_e__data.html#a94b04108aa1a9406eb3c5eb61749140b',1,'ProSHADE_internal_data::ProSHADE_data']]],
  ['rottrsjsonfile_1275',['rotTrsJSONFile',['../class_pro_s_h_a_d_e__settings.html#a30a0c63c3ab63d603776c9a16e1e4044',1,'ProSHADE_settings']]],
  ['rrpmatrices_1276',['rrpMatrices',['../class_pro_s_h_a_d_e__internal__data_1_1_pro_s_h_a_d_e__data.html#af8b72cbc56a4f72d0557e01a8101d435',1,'ProSHADE_internal_data::ProSHADE_data']]]
];
