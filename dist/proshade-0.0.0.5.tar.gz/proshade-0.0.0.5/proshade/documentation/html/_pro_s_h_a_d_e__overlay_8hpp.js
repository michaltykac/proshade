var _pro_s_h_a_d_e__overlay_8hpp =
[
    [ "allocateTranslationFunctionMemory", "_pro_s_h_a_d_e__overlay_8hpp.html#a5f5eacf55d707e1d80d3df360fc0fe91", null ],
    [ "combineFourierForTranslation", "_pro_s_h_a_d_e__overlay_8hpp.html#a2a0722746f5c10a2ce4805513cb99fe9", null ],
    [ "computeAngularThreshold", "_pro_s_h_a_d_e__overlay_8hpp.html#a78c51dc39b75ffb4731c7219b25e290b", null ],
    [ "computeBeforeAfterZeroCounts", "_pro_s_h_a_d_e__overlay_8hpp.html#a6f02ec45f8f865fe5a7142509f48e41a", null ],
    [ "findHighestValueInMap", "_pro_s_h_a_d_e__overlay_8hpp.html#a75e695f0a6b627e6a670c5e379230f4c", null ],
    [ "freeTranslationFunctionMemory", "_pro_s_h_a_d_e__overlay_8hpp.html#a448b6438ea9979e18af75f419f175603", null ],
    [ "getOptimalRotation", "_pro_s_h_a_d_e__overlay_8hpp.html#a92cc970ba9d1e6ab220a0c947ebd5567", null ],
    [ "getOptimalTranslation", "_pro_s_h_a_d_e__overlay_8hpp.html#a96c978e561ed489efc681f640332256a", null ],
    [ "initialiseInverseSHComputation", "_pro_s_h_a_d_e__overlay_8hpp.html#ac173210899aeeae2e207f9acdd7670a7", null ],
    [ "paddMapWithZeroes", "_pro_s_h_a_d_e__overlay_8hpp.html#a1e7fa43107bc9a9fce49d5954a93c962", null ]
];