var _pro_s_h_a_d_e__distances_8hpp =
[
    [ "allocateInvSOFTWorkspaces", "_pro_s_h_a_d_e__distances_8hpp.html#adf3050bb282928f5c1639dcdf2b3261f", null ],
    [ "allocateTrSigmaWorkspace", "_pro_s_h_a_d_e__distances_8hpp.html#a365752e40ab7c1f09fb4b31827a43dba", null ],
    [ "computeEMatrices", "_pro_s_h_a_d_e__distances_8hpp.html#add48230d67bd69305df058d29a588507", null ],
    [ "computeEMatricesForLM", "_pro_s_h_a_d_e__distances_8hpp.html#a8ed62a245d4fa9750f98b60d755b61c1", null ],
    [ "computeEnergyLevelsDescriptor", "_pro_s_h_a_d_e__distances_8hpp.html#a1a977a344baa3b1697743060789bceb5", null ],
    [ "computeInverseSOFTTransform", "_pro_s_h_a_d_e__distances_8hpp.html#a3cdde76bf20d9cd5d756ffde2d3dc854", null ],
    [ "computeRotationunctionDescriptor", "_pro_s_h_a_d_e__distances_8hpp.html#a0f062b77c4b5360a17249e74e6a15538", null ],
    [ "computeRRPPearsonCoefficients", "_pro_s_h_a_d_e__distances_8hpp.html#acde4bb62c09903a347ecde6f0a5302b1", null ],
    [ "computeSphericalHarmonicsMagnitude", "_pro_s_h_a_d_e__distances_8hpp.html#a22db876a8cca08073f4db031996f537b", null ],
    [ "computeTraceSigmaDescriptor", "_pro_s_h_a_d_e__distances_8hpp.html#a34bad8d846082de4dc61870d67e762cf", null ],
    [ "computeWeightsForEMatricesForLM", "_pro_s_h_a_d_e__distances_8hpp.html#ac086a02b5fd1fb0b32c2084a01aa927d", null ],
    [ "generateSO3CoeffsFromEMatrices", "_pro_s_h_a_d_e__distances_8hpp.html#afacb5240b508ea28b64cacf395b47dba", null ],
    [ "isBandWithinShell", "_pro_s_h_a_d_e__distances_8hpp.html#a6e15740000a0079151a2d24dbbdebb2e", null ],
    [ "normaliseEMatrices", "_pro_s_h_a_d_e__distances_8hpp.html#ac96ff1a23997199af76e58885a1ee1e2", null ],
    [ "prepareInvSOFTPlan", "_pro_s_h_a_d_e__distances_8hpp.html#a7a46703d08283073826820000007ec05", null ],
    [ "releaseInvSOFTMemory", "_pro_s_h_a_d_e__distances_8hpp.html#ad7d8c822491454700995e0f1bc702e48", null ],
    [ "releaseTrSigmaWorkspace", "_pro_s_h_a_d_e__distances_8hpp.html#a3dd86bf34be4f3398a83a4865738ddf2", null ]
];