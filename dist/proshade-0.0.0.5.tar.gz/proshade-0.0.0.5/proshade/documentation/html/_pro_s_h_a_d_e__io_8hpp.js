var _pro_s_h_a_d_e__io_8hpp =
[
    [ "InputType", "_pro_s_h_a_d_e__io_8hpp.html#a80a7305e00c670509c352f2e6c6a7964", [
      [ "UNKNOWN", "_pro_s_h_a_d_e__io_8hpp.html#a80a7305e00c670509c352f2e6c6a7964a931e41099ae6c64ea034b6485a46dfaa", null ],
      [ "PDB", "_pro_s_h_a_d_e__io_8hpp.html#a80a7305e00c670509c352f2e6c6a7964a02c37da7e1f9b2546ac6f8dab137dc25", null ],
      [ "MAP", "_pro_s_h_a_d_e__io_8hpp.html#a80a7305e00c670509c352f2e6c6a7964a2ebd61b90723c41f6f03a4a1f5791f1e", null ]
    ] ],
    [ "figureDataType", "_pro_s_h_a_d_e__io_8hpp.html#a63ae2cc7f413d224e5d651ed579e9afb", null ],
    [ "isFileMAP", "_pro_s_h_a_d_e__io_8hpp.html#ae496132c658b22a5abb5d7aaca5e1f56", null ],
    [ "isFilePDB", "_pro_s_h_a_d_e__io_8hpp.html#abc5e6a82b6b44e3666abfc190dc0bc64", null ],
    [ "readInMapData", "_pro_s_h_a_d_e__io_8hpp.html#ad93f9644c5b132193b4ddd282f50abce", null ],
    [ "readInMapHeader", "_pro_s_h_a_d_e__io_8hpp.html#a9677e06f0781855b9046aab1b3638831", null ],
    [ "writeOutMapHeader", "_pro_s_h_a_d_e__io_8hpp.html#a2e438f3d348e3e065f798031d5a33d09", null ],
    [ "writeRotationTranslationJSON", "_pro_s_h_a_d_e__io_8hpp.html#a9f714e15a7bc56dbe846fda6bb1d9c9e", null ]
];