var _pro_s_h_a_d_e__peak_search_8hpp =
[
    [ "allocatePeakOptimisationMemory", "_pro_s_h_a_d_e__peak_search_8hpp.html#aae6654470760e4848182efabbcfc0487", null ],
    [ "allocateSmoothingZScoreMemory", "_pro_s_h_a_d_e__peak_search_8hpp.html#a26e06bc5d7848e1f9da5aeac60ceb989", null ],
    [ "findAllDisconnectedIslands", "_pro_s_h_a_d_e__peak_search_8hpp.html#ab591c4642541dea6eddb4d19d41b6c42", null ],
    [ "findAllPointNeighbours", "_pro_s_h_a_d_e__peak_search_8hpp.html#a34517023194b4c96e1e4e378dbc70e34", null ],
    [ "findAllPointsAboveNeighbours", "_pro_s_h_a_d_e__peak_search_8hpp.html#a5b70a7d73951db96021a5451b6b3f368", null ],
    [ "findAllSmoothedZScorePeaksWithNeighbours", "_pro_s_h_a_d_e__peak_search_8hpp.html#a4cdab52c30f5b34effa4dbf4352bf85e", null ],
    [ "getAllPeaksNaive", "_pro_s_h_a_d_e__peak_search_8hpp.html#a9874fdfe82bd0d75958f9b250750fd56", null ],
    [ "getAllPeaksSmoothedZ", "_pro_s_h_a_d_e__peak_search_8hpp.html#ae1faf29aa9f12daea7688c7e24e94ad7", null ],
    [ "getBestPeakEulerAngsNaive", "_pro_s_h_a_d_e__peak_search_8hpp.html#ae8a54558e9c9c28568c441a601811449", null ],
    [ "getBestPeakEulerAngsSmoothedZ", "_pro_s_h_a_d_e__peak_search_8hpp.html#abbf17a40fb05ae159e7ff915f5e26243", null ],
    [ "getSmoothedZScore1D", "_pro_s_h_a_d_e__peak_search_8hpp.html#adb3b37d77e87360f41cb9529a6e84ce0", null ],
    [ "getXAxisArraysSmoothedZScorePeaks", "_pro_s_h_a_d_e__peak_search_8hpp.html#a31ee66ea091e22a8abbc77a1afad70cc", null ],
    [ "getYAxisArraysSmoothedZScorePeaks", "_pro_s_h_a_d_e__peak_search_8hpp.html#a7081c50797a114cd519dd28ba2ac6764", null ],
    [ "getZAxisArraysSmoothedZScorePeaks", "_pro_s_h_a_d_e__peak_search_8hpp.html#aa6466285a9f941c080343e69a01a26d0", null ],
    [ "optimisePeakPositions", "_pro_s_h_a_d_e__peak_search_8hpp.html#ad294ce59d3158bb67c3afd553d8c8793", null ],
    [ "pointsAboveNeighboursRemoveSmallHeight", "_pro_s_h_a_d_e__peak_search_8hpp.html#a80392ad926f2c048de1cc20b47b4dff2", null ],
    [ "releasePeakOptimisationMemory", "_pro_s_h_a_d_e__peak_search_8hpp.html#a2f0f9ca11f49a15c4d40f757da9c2eb3", null ],
    [ "releaseSmoothingZScoreMemory", "_pro_s_h_a_d_e__peak_search_8hpp.html#a8c0f7d3f046929631a3ff42fa3747d6e", null ]
];