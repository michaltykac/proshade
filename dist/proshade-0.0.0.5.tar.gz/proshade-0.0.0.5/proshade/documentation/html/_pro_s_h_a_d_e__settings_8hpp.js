var _pro_s_h_a_d_e__settings_8hpp =
[
    [ "ProSHADE_settings", "class_pro_s_h_a_d_e__settings.html", "class_pro_s_h_a_d_e__settings" ],
    [ "__PROSHADE_SETTINGS__", "_pro_s_h_a_d_e__settings_8hpp.html#adbd9e29a67267d0dbd58997b09ebbab6", null ]
];