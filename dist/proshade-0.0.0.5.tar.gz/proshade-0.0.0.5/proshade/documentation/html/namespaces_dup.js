var namespaces_dup =
[
    [ "ProSHADE_internal_data", "namespace_pro_s_h_a_d_e__internal__data.html", null ],
    [ "ProSHADE_internal_distances", "namespace_pro_s_h_a_d_e__internal__distances.html", null ],
    [ "ProSHADE_internal_io", "namespace_pro_s_h_a_d_e__internal__io.html", null ],
    [ "ProSHADE_internal_mapManip", "namespace_pro_s_h_a_d_e__internal__map_manip.html", null ],
    [ "ProSHADE_internal_maths", "namespace_pro_s_h_a_d_e__internal__maths.html", null ],
    [ "ProSHADE_internal_messages", "namespace_pro_s_h_a_d_e__internal__messages.html", null ],
    [ "ProSHADE_internal_misc", "namespace_pro_s_h_a_d_e__internal__misc.html", null ],
    [ "ProSHADE_internal_overlay", "namespace_pro_s_h_a_d_e__internal__overlay.html", null ],
    [ "ProSHADE_internal_peakSearch", "namespace_pro_s_h_a_d_e__internal__peak_search.html", null ],
    [ "ProSHADE_internal_precomputedVals", "namespace_pro_s_h_a_d_e__internal__precomputed_vals.html", null ],
    [ "ProSHADE_internal_spheres", "namespace_pro_s_h_a_d_e__internal__spheres.html", null ],
    [ "ProSHADE_internal_sphericalHarmonics", "namespace_pro_s_h_a_d_e__internal__spherical_harmonics.html", null ],
    [ "ProSHADE_internal_symmetry", "namespace_pro_s_h_a_d_e__internal__symmetry.html", null ],
    [ "ProSHADE_internal_tasks", "namespace_pro_s_h_a_d_e__internal__tasks.html", null ],
    [ "ProSHADE_internal_wigner", "namespace_pro_s_h_a_d_e__internal__wigner.html", null ]
];