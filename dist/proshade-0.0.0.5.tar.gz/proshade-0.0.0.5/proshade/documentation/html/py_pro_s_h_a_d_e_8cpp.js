var py_pro_s_h_a_d_e_8cpp =
[
    [ "add_settingsClass", "py_pro_s_h_a_d_e_8cpp.html#a700083a97be64b1ffe485d3056a9e5f2", null ]
];